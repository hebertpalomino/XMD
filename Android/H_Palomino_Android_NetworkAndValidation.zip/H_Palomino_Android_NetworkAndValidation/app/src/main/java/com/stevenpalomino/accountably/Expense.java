package com.stevenpalomino.accountably;

import java.io.Serializable;


public class Expense implements Serializable {

    public String mName;
    public Number mAmount;
    public Number mPriority;
    public String objectID;


}
